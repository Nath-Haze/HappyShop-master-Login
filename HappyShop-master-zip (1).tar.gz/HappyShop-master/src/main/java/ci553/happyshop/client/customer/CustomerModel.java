package ci553.happyshop.client.customer;

import ci553.happyshop.catalogue.Order;
import ci553.happyshop.catalogue.Product;
import ci553.happyshop.storageAccess.DatabaseRW;
import ci553.happyshop.orderManagement.OrderHub;
import ci553.happyshop.utility.StorageLocation;
import ci553.happyshop.utility.ProductListFormatter;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * TODO
 * You can either directly modify the CustomerModel class to implement the required tasks,
 * or create a subclass of CustomerModel and override specific methods where appropriate.
 */
public class CustomerModel {
    public CustomerView cusView;
    public DatabaseRW databaseRW; //Interface type, not specific implementation
                                  //Benefits: Flexibility: Easily change the database implementation.

    private Product theProduct =null; // product found from search
    private ArrayList<Product> trolley =  new ArrayList<>(); // a list of products in trolley

    // Four UI elements to be passed to CustomerView for display updates.
    private String imageName = "imageHolder.jpg";                // Image to show in product preview (Search Page)
    private String displayLaSearchResult = "No Product was searched yet"; // Label showing search result message (Search Page)
    private String displayTaTrolley = "";                                // Text area content showing current trolley items (Trolley Page)
    private String displayTaReceipt = "";                              // Text area content showing receipt after checkout (Receipt Page)

    void showAlert(String title, String message){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    void login(){
        Stage stage = new Stage();
        Label userLabel = new Label("Username: ");
        TextField userField = new TextField();
        Label passLabel = new Label("Password: ");
        TextField passField = new TextField();
        Button login = new Button("Login");
        login.setOnAction(e ->{
            String username = userField.getText();
            String password = passField.getText();
            boolean found = false;
            File file = new File("loginInfo.txt");
            try (Scanner myReader = new Scanner(file)) {
                while (myReader.hasNextLine()) {
                    String data = myReader.nextLine();
                    String[] datalist = data.split(",");
                    if (datalist[0].equals(username) && datalist[1].equals(password)){
                        found = true;
                    }
                }
            } catch (FileNotFoundException f) {
                showAlert("Error", "File not found");
            }
            if (found) {
                showAlert("Welcome", "logged in");
            } else {
                showAlert("Error", "Incorrect username/password");
            }
        });
        VBox layout = new VBox(10);
        layout.getChildren().addAll(userLabel, userField, passLabel, passField, login);
        Scene scene = new Scene(layout, 350, 350);
        stage.setScene(scene);
        stage.show();
    }

    void change(){
        Stage stage = new Stage();
        Label usernameLabel = new Label("Username: ");
        TextField usernameField = new TextField();
        Label oldpasswordLabel = new Label("Old password: ");
        TextField oldpasswordField = new TextField();
        Label newpasswordLabel = new Label("New password");
        TextField newpasswordField = new TextField();
        Button change = new Button("Change");
        change.setOnAction(e ->{
            String username = usernameField.getText();
            String oldpassword = oldpasswordField.getText();
            String newpassword = newpasswordField.getText();
            boolean valid = true;
            boolean found = false;
            if (username.isEmpty() || oldpassword.isEmpty() || newpassword.isEmpty()) {
                showAlert("Error", "Fill in all fields");
                valid = false;
            }
            File file = new File("loginInfo.txt");
            StringBuilder updatedContent = new StringBuilder();
            if (valid) {
                try (Scanner myReader = new Scanner(file)) {
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        String[] datalist = data.split(",");
                        if (datalist[0].equals(username) && datalist[1].equals(oldpassword)) {
                            found = true;
                            updatedContent.append(username).append(",").append(newpassword).append("\n");
                        } else {
                            updatedContent.append(data).append("\n");
                        }
                    }
                } catch (FileNotFoundException f) {
                    showAlert("Error", "File not found");
                }
            }
            if (found) {
                try (FileWriter writer = new FileWriter(file)) {
                    writer.write(updatedContent.toString());
                    showAlert("Success", "Password changed");
                } catch (IOException ex) {
                    showAlert("Error", "Could not write to file");
                }
            } else {
                showAlert("Error", "Username or password incorrect");
            }
        });
        VBox layout = new VBox(10);
        layout.getChildren().addAll(usernameLabel, usernameField, oldpasswordLabel, oldpasswordField, newpasswordLabel, newpasswordField, change);
        Scene scene = new Scene(layout, 350, 350);
        stage.setScene(scene);
        stage.show();
    }

    void create(){
        Stage stage = new Stage();
        Label usernameLabel = new Label("Username: ");
        TextField usernameField = new TextField();
        Label passwordLabel = new Label("Password: ");
        TextField passwordField = new TextField();
        Button create = new Button("Create");
        create.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            boolean valid = true;
            if (password.isEmpty() || username.isEmpty()) {
                showAlert("Error", "Fill in all fields");
                valid = false;
            };
            if (valid) {
                try {
                    FileWriter writer = new FileWriter("loginInfo.txt", true);
                    String text = username + "," + password + "\n";
                    writer.write(text);
                    writer.close();
                    showAlert("News", "Account created");
                } catch (IOException q){
                    showAlert("Error", "Failed to save account");
                };
            };
        });
        VBox layout = new VBox(10);
        layout.getChildren().addAll(usernameLabel, usernameField, passwordLabel, passwordField, create);
        Scene scene = new Scene(layout, 350, 350);
        stage.setScene(scene);
        stage.show();
    }

    //SELECT productID, description, image, unitPrice,inStock quantity
    void search() throws SQLException {
        String productId = cusView.tfId.getText().trim();
        if(!productId.isEmpty()){
            theProduct = databaseRW.searchByProductId(productId); //search database
            if(theProduct != null && theProduct.getStockQuantity()>0){
                double unitPrice = theProduct.getUnitPrice();
                String description = theProduct.getProductDescription();
                int stock = theProduct.getStockQuantity();

                String baseInfo = String.format("Product_Id: %s\n%s,\nPrice: £%.2f", productId, description, unitPrice);
                String quantityInfo = stock < 100 ? String.format("\n%d units left.", stock) : "";
                displayLaSearchResult = baseInfo + quantityInfo;
                System.out.println(displayLaSearchResult);
            }
            else{
                theProduct=null;
                displayLaSearchResult = "No Product was found with ID " + productId;
                System.out.println("No Product was found with ID " + productId);
            }
        }else{
            theProduct=null;
            displayLaSearchResult = "Please type ProductID";
            System.out.println("Please type ProductID.");
        }
        updateView();
    }

    void addToTrolley(){
        if(theProduct!= null){

            // trolley.add(theProduct) — Product is appended to the end of the trolley.
            // To keep the trolley organized, add code here or call a method that:
            //TODO
            // 1. Merges items with the same product ID (combining their quantities).
            // 2. Sorts the products in the trolley by product ID.
            trolley.add(theProduct);
            displayTaTrolley = ProductListFormatter.buildString(trolley); //build a String for trolley so that we can show it
        }
        else{
            displayLaSearchResult = "Please search for an available product before adding it to the trolley";
            System.out.println("must search and get an available product before add to trolley");
        }
        displayTaReceipt=""; // Clear receipt to switch back to trolleyPage (receipt shows only when not empty)
        updateView();
    }

    void checkOut() throws IOException, SQLException {
        if(!trolley.isEmpty()){
            // Group the products in the trolley by productId to optimize stock checking
            // Check the database for sufficient stock for all products in the trolley.
            // If any products are insufficient, the update will be rolled back.
            // If all products are sufficient, the database will be updated, and insufficientProducts will be empty.
            // Note: If the trolley is already organized (merged and sorted), grouping is unnecessary.
            ArrayList<Product> groupedTrolley= groupProductsById(trolley);
            ArrayList<Product> insufficientProducts= databaseRW.purchaseStocks(groupedTrolley);

            if(insufficientProducts.isEmpty()){ // If stock is sufficient for all products
                //get OrderHub and tell it to make a new Order
                OrderHub orderHub =OrderHub.getOrderHub();
                Order theOrder = orderHub.newOrder(trolley);
                trolley.clear();
                displayTaTrolley ="";
                displayTaReceipt = String.format(
                        "Order_ID: %s\nOrdered_Date_Time: %s\n%s",
                        theOrder.getOrderId(),
                        theOrder.getOrderedDateTime(),
                        ProductListFormatter.buildString(theOrder.getProductList())
                );
                System.out.println(displayTaReceipt);
            }
            else{ // Some products have insufficient stock — build an error message to inform the customer
                StringBuilder errorMsg = new StringBuilder();
                for(Product p : insufficientProducts){
                    errorMsg.append("\u2022 "+ p.getProductId()).append(", ")
                            .append(p.getProductDescription()).append(" (Only ")
                            .append(p.getStockQuantity()).append(" available, ")
                            .append(p.getOrderedQuantity()).append(" requested)\n");
                }
                theProduct=null;

                //TODO
                // Add the following logic here:
                // 1. Remove products with insufficient stock from the trolley.
                // 2. Trigger a message window to notify the customer about the insufficient stock, rather than directly changing displayLaSearchResult.
                //You can use the provided RemoveProductNotifier class and its showRemovalMsg method for this purpose.
                //remember close the message window where appropriate (using method closeNotifierWindow() of RemoveProductNotifier class)
                displayLaSearchResult = "Checkout failed due to insufficient stock for the following products:\n" + errorMsg.toString();
                System.out.println("stock is not enough");
            }
        }
        else{
            displayTaTrolley = "Your trolley is empty";
            System.out.println("Your trolley is empty");
        }
        updateView();
    }

    /**
     * Groups products by their productId to optimize database queries and updates.
     * By grouping products, we can check the stock for a given `productId` once, rather than repeatedly
     */
    private ArrayList<Product> groupProductsById(ArrayList<Product> proList) {
        Map<String, Product> grouped = new HashMap<>();
        for (Product p : proList) {
            String id = p.getProductId();
            if (grouped.containsKey(id)) {
                Product existing = grouped.get(id);
                existing.setOrderedQuantity(existing.getOrderedQuantity() + p.getOrderedQuantity());
            } else {
                // Make a shallow copy to avoid modifying the original
                grouped.put(id,new Product(p.getProductId(),p.getProductDescription(),
                        p.getProductImageName(),p.getUnitPrice(),p.getStockQuantity()));
            }
        }
        return new ArrayList<>(grouped.values());
    }

    void cancel(){
        trolley.clear();
        displayTaTrolley="";
        updateView();
    }
    void closeReceipt(){
        displayTaReceipt="";
    }

    void updateView() {
        if(theProduct != null){
            imageName = theProduct.getProductImageName();
            String relativeImageUrl = StorageLocation.imageFolder +imageName; //relative file path, eg images/0001.jpg
            // Get the full absolute path to the image
            Path imageFullPath = Paths.get(relativeImageUrl).toAbsolutePath();
            imageName = imageFullPath.toUri().toString(); //get the image full Uri then convert to String
            System.out.println("Image absolute path: " + imageFullPath); // Debugging to ensure path is correct
        }
        else{
            imageName = "imageHolder.jpg";
        }
        cusView.update(imageName, displayLaSearchResult, displayTaTrolley,displayTaReceipt);
    }
     // extra notes:
     //Path.toUri(): Converts a Path object (a file or a directory path) to a URI object.
     //File.toURI(): Converts a File object (a file on the filesystem) to a URI object

    //for test only
    public ArrayList<Product> getTrolley() {
        return trolley;
    }
}
